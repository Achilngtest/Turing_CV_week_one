# Numpy
# np.array()
#image list = [[[225, 0, 0]]]
#image = np.array(image list)
#np.zeros() / np.ones()
#blank image = np.zeros((224, 224, 3), np.uint8)
#np.arange()
#np.linspace()
#np.random.rand() / np.random.randn()
#np.reshape()
#
