import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
file_path = r'C:\Users\黄小悠\Desktop\附件.xlsx'
df = pd.read_excel(file_path)

plt.figure(figsize=(12, 4))

scatter_pairs = [('在途时长', '自有变动成本'), ('在途时长', '外部承运商成本'),('自有变动成本', '外部承运商成本')]

for i,(x_col, y_col) in enumerate(scatter_pairs, 1):
    plt.subplot(1, 3, i)
    plt.scatter(df[x_col], df[y_col])
    plt.xlabel(x_col)
    plt.ylabel(y_col)
    plt.title(f'{x_col} vs {y_col}')

    plt.tight_layout()
    plt.show()

stats = df.describe().T[['max', 'min', 'mean', '50%']]
stats.columns = ['最大值', '最小值', '平均值', '中位数']
print("各数据统计量: ")
print(stats)

df['总成本'] = df['自有变动成本'] + df['外部承运商成本']
df['时均成本'] = df['总成本'] / df['在途时长']

plt.figure(figsize=(10, 6))
plt.bar(df['车队编码'].unique(), df.groupby('车队编码')['时均成本'].min())
plt.xlabel('车队编码')
plt.ylabel('最佳时均成本')
plt.title('各车队最佳时均成本对比')
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()